# Testing and Quality Assurance API - Build

This is a FastAPI-based backend experiment for Testing and Quality Assurance.

## Features

- User authentication with token-based security
- CRUD operations for user management
- Health check endpoint
- CORS support for cross-origin requests

## Endpoints

- `GET /api/health` - Health check
- `POST /api/login` - User login (password: admin123)
- `GET /api/users` - List all users (requires auth)
- `GET /api/users/{user_id}` - Get user by ID (requires auth)
- `POST /api/users` - Create user (requires auth)
- `PUT /api/users/{user_id}` - Update user (requires auth)
- `DELETE /api/users/{user_id}` - Delete user (requires auth)

## Quick Start

### Local Development

```bash
# Setup and run backend
# Windows:
setup.bat

# Linux/macOS:
./setup.sh

# Optional flags:
# --test          Run tests before starting server
# --skip-install  Skip dependency installation
```

The API will be available at `http://localhost:8000`
API docs available at `http://localhost:8000/docs`

### Docker Build

```bash
# Build image
docker build -t exp9-backend .

# Run container
docker run -p 8000:8000 exp9-backend
```

### Docker Compose

```bash
# Build and run
docker-compose up

# Stop
docker-compose down
```

## Running Tests

```bash
pytest
```

## Default Credentials

- Email: any valid email
- Password: `admin123`

## Generated Token Format

Tokens follow the format: `token-for-{email}`
