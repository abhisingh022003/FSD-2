def create_fake_token(email: str) -> str:
    return f"token-for-{email}"

def verify_token(token: str | None) -> bool:
    return token is not None and token.startswith("token-for-")
