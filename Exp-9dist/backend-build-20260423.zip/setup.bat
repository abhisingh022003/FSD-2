@echo off
setlocal
REM Setup + run script for FastAPI Testing and QA Backend

set "RUN_TESTS=0"
set "SKIP_INSTALL=0"

for %%A in (%*) do (
    if /I "%%~A"=="--test" set "RUN_TESTS=1"
    if /I "%%~A"=="--skip-install" set "SKIP_INSTALL=1"
)

echo.
echo ======================================
echo Testing and QA API - Setup and Run
echo ======================================
echo.

if "%SKIP_INSTALL%"=="1" (
    echo [1/3] Skipping dependency installation --skip-install
) else (
    echo [1/3] Installing Python dependencies...
    python -m pip install --disable-pip-version-check -r requirements.txt
    if %errorlevel% neq 0 (
        echo Error installing dependencies
        exit /b 1
    )
)

echo.
if "%RUN_TESTS%"=="1" (
    echo [2/3] Running tests...
    python -m pytest -v
    if %errorlevel% neq 0 (
        echo Tests failed
        exit /b 1
    )
) else (
    echo [2/3] Skipping tests - use --test to run them
)

echo.
echo [3/3] Starting backend server...
echo API docs: http://localhost:8000/docs
echo.
python -m uvicorn main:app --reload
