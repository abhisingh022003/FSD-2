from fastapi.testclient import TestClient
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from main import app

client = TestClient(app)

VALID_HEADERS = {"Authorization": "Bearer token-for-admin@example.com"}

def test_health_check():
    response = client.get("/api/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

def test_login_success():
    response = client.post("/api/login", json={
        "email": "admin@example.com",
        "password": "admin123"
    })
    assert response.status_code == 200
    data = response.json()
    assert "access_token" in data
    assert data["token_type"] == "bearer"

def test_login_failure():
    response = client.post("/api/login", json={
        "email": "admin@example.com",
        "password": "wrong"
    })
    assert response.status_code == 401

def test_get_users_requires_auth():
    response = client.get("/api/users")
    assert response.status_code == 401

def test_get_users_success():
    response = client.get("/api/users", headers=VALID_HEADERS)
    assert response.status_code == 200
    assert isinstance(response.json(), list)

def test_create_user():
    response = client.post(
        "/api/users",
        headers=VALID_HEADERS,
        json={"name": "Charlie", "email": "charlie@example.com"}
    )
    assert response.status_code == 201
    data = response.json()
    assert data["name"] == "Charlie"

def test_update_user():
    response = client.put(
        "/api/users/1",
        headers=VALID_HEADERS,
        json={"name": "Alice Updated"}
    )
    assert response.status_code == 200
    assert response.json()["name"] == "Alice Updated"

def test_delete_user():
    response = client.delete("/api/users/2", headers=VALID_HEADERS)
    assert response.status_code == 200
    assert response.json()["message"] == "User deleted"
