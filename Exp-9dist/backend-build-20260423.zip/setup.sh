#!/bin/bash
# Setup + run script for FastAPI Testing and QA Backend

RUN_TESTS=0
SKIP_INSTALL=0

for arg in "$@"; do
    if [ "$arg" = "--test" ]; then
        RUN_TESTS=1
    fi
    if [ "$arg" = "--skip-install" ]; then
        SKIP_INSTALL=1
    fi
done

echo ""
echo "======================================"
echo "Testing and QA API - Setup and Run"
echo "======================================"
echo ""

if [ "$SKIP_INSTALL" -eq 1 ]; then
    echo "[1/3] Skipping dependency installation (--skip-install)"
else
    echo "[1/3] Installing Python dependencies..."
    python -m pip install --disable-pip-version-check -r requirements.txt
    if [ $? -ne 0 ]; then
        echo "Error installing dependencies"
        exit 1
    fi
fi

echo ""
if [ "$RUN_TESTS" -eq 1 ]; then
    echo "[2/3] Running tests..."
    python -m pytest -v
    if [ $? -ne 0 ]; then
        echo "Tests failed"
        exit 1
    fi
else
    echo "[2/3] Skipping tests (use --test to run them)"
fi

echo ""
echo "[3/3] Starting backend server..."
echo "API docs: http://localhost:8000/docs"
echo ""
python -m uvicorn main:app --reload
