from fastapi import FastAPI, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware

from schemas import LoginRequest, TokenResponse, UserCreate, UserUpdate
from storage import get_all_users, get_user, add_user, update_user, delete_user
from auth import create_fake_token, verify_token

app = FastAPI(title="Testing and Quality Assurance API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/api/health")
def health_check():
    return {"status": "ok"}

@app.post("/api/login", response_model=TokenResponse)
def login(payload: LoginRequest):
    if payload.password != "admin123":
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = create_fake_token(payload.email)
    return {"access_token": token, "token_type": "bearer"}

@app.get("/api/users")
def list_users(authorization: str | None = Header(default=None)):
    if not verify_token(authorization.replace("Bearer ", "") if authorization else None):
        raise HTTPException(status_code=401, detail="Unauthorized")
    return get_all_users()

@app.get("/api/users/{user_id}")
def read_user(user_id: int, authorization: str | None = Header(default=None)):
    if not verify_token(authorization.replace("Bearer ", "") if authorization else None):
        raise HTTPException(status_code=401, detail="Unauthorized")
    user = get_user(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user

@app.post("/api/users", status_code=201)
def create_user(payload: UserCreate, authorization: str | None = Header(default=None)):
    if not verify_token(authorization.replace("Bearer ", "") if authorization else None):
        raise HTTPException(status_code=401, detail="Unauthorized")
    return add_user(payload.name, payload.email)

@app.put("/api/users/{user_id}")
def edit_user(user_id: int, payload: UserUpdate, authorization: str | None = Header(default=None)):
    if not verify_token(authorization.replace("Bearer ", "") if authorization else None):
        raise HTTPException(status_code=401, detail="Unauthorized")
    updated = update_user(user_id, payload.model_dump())
    if not updated:
        raise HTTPException(status_code=404, detail="User not found")
    return updated

@app.delete("/api/users/{user_id}")
def remove_user(user_id: int, authorization: str | None = Header(default=None)):
    if not verify_token(authorization.replace("Bearer ", "") if authorization else None):
        raise HTTPException(status_code=401, detail="Unauthorized")
    deleted = delete_user(user_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="User not found")
    return {"message": "User deleted"}
