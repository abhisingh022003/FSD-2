from typing import List, Dict

users_db: List[Dict] = [
    {"id": 1, "name": "Alice", "email": "alice@example.com"},
    {"id": 2, "name": "Bob", "email": "bob@example.com"},
]

def get_all_users():
    return users_db

def get_user(user_id: int):
    for user in users_db:
        if user["id"] == user_id:
            return user
    return None

def add_user(name: str, email: str):
    new_id = max([u["id"] for u in users_db], default=0) + 1
    user = {"id": new_id, "name": name, "email": email}
    users_db.append(user)
    return user

def update_user(user_id: int, data: dict):
    user = get_user(user_id)
    if not user:
        return None
    if "name" in data and data["name"] is not None:
        user["name"] = data["name"]
    if "email" in data and data["email"] is not None:
        user["email"] = data["email"]
    return user

def delete_user(user_id: int):
    user = get_user(user_id)
    if not user:
        return False
    users_db.remove(user)
    return True
