from datetime import datetime, timedelta
from pathlib import Path
import shutil

from fastapi import Depends, FastAPI, File, HTTPException, Query, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError, jwt
from pydantic import BaseModel

app = FastAPI(title="Experiment 7 API - Python Backend")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

SECRET_KEY = "replace_this_with_a_secure_secret"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60
security = HTTPBearer()

UPLOAD_DIR = Path("uploads")
UPLOAD_DIR.mkdir(exist_ok=True)

# Demo in-memory data store
users_db = [
    {"id": 1, "name": "John", "email": "john@example.com", "password": "1234"},
    {"id": 2, "name": "Jane", "email": "jane@example.com", "password": "1234"},
]


class LoginRequest(BaseModel):
    email: str
    password: str


class UserCreate(BaseModel):
    name: str
    email: str
    password: str


class UserUpdate(BaseModel):
    name: str | None = None
    email: str | None = None


class UserOut(BaseModel):
    id: int
    name: str
    email: str


def create_access_token(data: dict, expires_minutes: int = ACCESS_TOKEN_EXPIRE_MINUTES):
    payload = data.copy()
    payload["exp"] = datetime.utcnow() + timedelta(minutes=expires_minutes)
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)


def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    token = credentials.credentials
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = payload.get("sub")
        if user_id is None:
            raise HTTPException(status_code=401, detail="Invalid token")
        user = next((u for u in users_db if u["id"] == int(user_id)), None)
        if user is None:
            raise HTTPException(status_code=401, detail="User not found")
        return user
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid or expired token")


@app.get("/api/health")
def health_check():
    return {"status": "ok", "message": "Python FastAPI backend is running"}


@app.post("/api/login")
def login(payload: LoginRequest):
    user = next(
        (u for u in users_db if u["email"] == payload.email and u["password"] == payload.password),
        None,
    )
    if not user:
        raise HTTPException(status_code=401, detail="Invalid email or password")

    token = create_access_token({"sub": str(user["id"])})
    return {
        "message": "Login successful",
        "token": token,
        "user": {"id": user["id"], "name": user["name"], "email": user["email"]},
    }


@app.get("/api/users", response_model=list[UserOut])
def get_users(current_user: dict = Depends(get_current_user)):
    return [{"id": u["id"], "name": u["name"], "email": u["email"]} for u in users_db]


@app.get("/api/users/{user_id}", response_model=UserOut)
def get_user(user_id: int, current_user: dict = Depends(get_current_user)):
    user = next((u for u in users_db if u["id"] == user_id), None)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return {"id": user["id"], "name": user["name"], "email": user["email"]}


@app.post("/api/users", response_model=UserOut, status_code=201)
def create_user(payload: UserCreate, current_user: dict = Depends(get_current_user)):
    if any(u["email"] == payload.email for u in users_db):
        raise HTTPException(status_code=400, detail="Email already exists")

    new_user = {
        "id": max([u["id"] for u in users_db], default=0) + 1,
        "name": payload.name,
        "email": payload.email,
        "password": payload.password,
    }
    users_db.append(new_user)
    return {"id": new_user["id"], "name": new_user["name"], "email": new_user["email"]}


@app.put("/api/users/{user_id}", response_model=UserOut)
def update_user(user_id: int, payload: UserUpdate, current_user: dict = Depends(get_current_user)):
    user = next((u for u in users_db if u["id"] == user_id), None)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    if payload.name is not None:
        user["name"] = payload.name
    if payload.email is not None:
        user["email"] = payload.email

    return {"id": user["id"], "name": user["name"], "email": user["email"]}


@app.delete("/api/users/{user_id}")
def delete_user(user_id: int, current_user: dict = Depends(get_current_user)):
    global users_db
    user = next((u for u in users_db if u["id"] == user_id), None)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    users_db = [u for u in users_db if u["id"] != user_id]
    return {"message": "User deleted successfully"}


@app.get("/api/search")
def search_users(q: str = Query(default=""), current_user: dict = Depends(get_current_user)):
    query = q.strip().lower()
    results = [
        {"id": u["id"], "name": u["name"], "email": u["email"]}
        for u in users_db
        if query in u["name"].lower() or query in u["email"].lower()
    ]
    return results


@app.get("/api/dashboard")
def get_dashboard(current_user: dict = Depends(get_current_user)):
    return {
        "total_users": len(users_db),
        "recent_users": [{"id": u["id"], "name": u["name"]} for u in users_db[-3:]],
        "authenticated_as": current_user["email"],
    }


@app.post("/api/upload")
def upload_file(file: UploadFile = File(...), current_user: dict = Depends(get_current_user)):
    destination = UPLOAD_DIR / file.filename
    with destination.open("wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    return {
        "message": "File uploaded successfully",
        "filename": file.filename,
        "saved_to": str(destination),
    }


# Run with:
# uvicorn main:app --reload
